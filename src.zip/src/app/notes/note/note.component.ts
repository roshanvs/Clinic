import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import {NoteService}from 'src/app/shared/note.service'
@Component({
  selector: 'app-note',
  templateUrl: './note.component.html',
  styleUrls: ['./note.component.scss']
})
export class NoteComponent implements OnInit {

  constructor(public noteService: NoteService) { }

  ngOnInit(): void {
  }
onSubmit(form: NgForm){
  console.log(form.value);
  let addId=this.noteService.formDataNote.noteId;

  if(addId==0 || addId == null){
    this.insertNote(form);
  }

}
insertNote(form?: NgForm){
  console.log("inserting a record");
  this.noteService.insertNote(form.value).subscribe(
    result=>{
      console.log(result);
      window.location.reload();
    }
  );
}



}
