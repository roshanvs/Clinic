import { Route } from '@angular/compiler/src/core';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppointmentService } from 'src/app/shared/appointment.service';
import { NoteService } from 'src/app/shared/note.service';

@Component({
  selector: 'app-note-list',
  templateUrl: './note-list.component.html',
  styleUrls: ['./note-list.component.scss']
})
export class NoteListComponent implements OnInit {

  constructor(public noteService: NoteService,
    private router: Router) {}

  ngOnInit(): void {
    this.noteService.getAllNotes();
    console.log(this.noteService.getAllNotes());
  }
  btnMenu= function () {
    this.router.navigateByUrl('/menu');
};

}
