import { Component, OnInit } from '@angular/core';
import { TestresultsComponent } from '../testresults.component';
import {TestresultService} from 'src/app/shared/testresult.service'
import { Router } from '@angular/router';
@Component({
  selector: 'app-testresult-list',
  templateUrl: './testresult-list.component.html',
  styleUrls: ['./testresult-list.component.scss']
})
export class TestresultListComponent implements OnInit {

  constructor(public testresultService: TestresultService,
              private router: Router) { }

  ngOnInit(): void {
    this.testresultService.getAlltestResults();
  }
  btnMenu= function () {
    this.router.navigateByUrl('/menu');
};

}
