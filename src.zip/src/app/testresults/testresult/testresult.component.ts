import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-testresult',
  templateUrl: './testresult.component.html',
  styleUrls: ['./testresult.component.scss']
})
export class TestresultComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
