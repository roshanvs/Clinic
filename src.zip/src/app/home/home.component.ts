import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {AppointmentService} from 'src/app/shared/appointment.service'
import { Appointment } from '../shared/appointment';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  appointments: Appointment[];
  docId: string = localStorage.getItem('doctorId');

  constructor(public appointmentService: AppointmentService,
              private router: Router) { }

  ngOnInit(): void {
    this.appointmentService.getAppointmentsByDoctor(Number(this.docId));
  }
  btnClick= function () {
    this.router.navigateByUrl('/menu');
};

    

}
