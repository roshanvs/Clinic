import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { MenuComponent } from './menu/menu.component';
import { MprescriptionListComponent } from './mprescriptions/mprescription-list/mprescription-list.component';
import { NoteListComponent } from './notes/note-list/note-list.component';
import { NoteComponent } from './notes/note/note.component';
import { TestresultListComponent } from './testresults/testresult-list/testresult-list.component';
import { TprescriptionListComponent } from './tprescriptions/tprescription-list/tprescription-list.component';

const routes: Routes = [

  
  {path: '',redirectTo: '/login',pathMatch:'full'},
  {path: 'login', component: LoginComponent},
  {path: 'home', component: HomeComponent},
  {path: 'menu', component: MenuComponent},
  {path: 'notelist', component: NoteListComponent},
  
  {path: 'testresultlist', component: TestresultListComponent},
  {path: 'tprescriptionlist', component: TprescriptionListComponent},
  {path: 'mprescriptionlist', component: MprescriptionListComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
