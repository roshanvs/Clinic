import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NotesComponent } from './notes/notes.component';
import { NoteComponent } from './notes/note/note.component';
import { NoteListComponent } from './notes/note-list/note-list.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { TestresultsComponent } from './testresults/testresults.component';
import { TestresultComponent } from './testresults/testresult/testresult.component';
import { TestresultListComponent } from './testresults/testresult-list/testresult-list.component';
import { MprescriptionComponent } from './mprescriptions/mprescription/mprescription.component';
import { MprescriptionsComponent } from './mprescriptions/mprescriptions.component';
import { MprescriptionListComponent } from './mprescriptions/mprescription-list/mprescription-list.component';
import { MenuComponent } from './menu/menu.component';
import { TprescriptionsComponent } from './tprescriptions/tprescriptions.component';
import { TprescriptionComponent } from './tprescriptions/tprescription/tprescription.component';
import { TprescriptionListComponent } from './tprescriptions/tprescription-list/tprescription-list.component';
import { NoteFormComponent } from './note-form/note-form.component';

@NgModule({
  declarations: [
    AppComponent,
    NotesComponent,
    NoteComponent,
    NoteListComponent,
    LoginComponent,
    HomeComponent,
    TestresultsComponent,
    TestresultComponent,
    TestresultListComponent,
    MprescriptionComponent,
    MprescriptionsComponent,
    MprescriptionListComponent,
    MenuComponent,
    TprescriptionsComponent,
    TprescriptionComponent,
    TprescriptionListComponent,
    NoteFormComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
