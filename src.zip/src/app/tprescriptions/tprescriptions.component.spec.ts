import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TprescriptionsComponent } from './tprescriptions.component';

describe('TprescriptionsComponent', () => {
  let component: TprescriptionsComponent;
  let fixture: ComponentFixture<TprescriptionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TprescriptionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TprescriptionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
