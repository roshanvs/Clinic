import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tprescription',
  templateUrl: './tprescription.component.html',
  styleUrls: ['./tprescription.component.scss']
})
export class TprescriptionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
