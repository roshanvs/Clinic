import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TprescriptionComponent } from './tprescription.component';

describe('TprescriptionComponent', () => {
  let component: TprescriptionComponent;
  let fixture: ComponentFixture<TprescriptionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TprescriptionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TprescriptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
