import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tprescriptions',
  templateUrl: './tprescriptions.component.html',
  styleUrls: ['./tprescriptions.component.scss']
})
export class TprescriptionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
