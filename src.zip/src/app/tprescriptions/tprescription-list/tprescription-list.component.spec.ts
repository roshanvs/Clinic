import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TprescriptionListComponent } from './tprescription-list.component';

describe('TprescriptionListComponent', () => {
  let component: TprescriptionListComponent;
  let fixture: ComponentFixture<TprescriptionListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TprescriptionListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TprescriptionListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
