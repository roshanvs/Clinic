import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {TprescriptionService} from 'src/app/shared/tprescription.service'
@Component({
  selector: 'app-tprescription-list',
  templateUrl: './tprescription-list.component.html',
  styleUrls: ['./tprescription-list.component.scss']
})
export class TprescriptionListComponent implements OnInit {

  constructor(public tprescriptionService: TprescriptionService,
              private router: Router) { }

  ngOnInit(): void {
    this.tprescriptionService.getAllNotes();
  }
  btnMenu= function () {
    this.router.navigateByUrl('/menu');
};

}
