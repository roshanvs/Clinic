export class Doctor {

    doctorId: number;
    specialisationId: number;
    userId: number;
}
