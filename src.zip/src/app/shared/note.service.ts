import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Note } from './note';

@Injectable({
  providedIn: 'root'
})
export class NoteService {
    formDataNote:Note=new Note(); 
    notes: Note[];
  constructor(private httpClient: HttpClient) { }
    getNotesByAppointment(id: number):Observable<any>{
      return this.httpClient.get(environment.apiUrl+"generalnotes/notes/"+id);

    }
    getAllNotes(){
      return this.httpClient.get(environment.apiUrl+"generalnotes").toPromise().then(
        response=> this.notes= response as Note[]
      );

    }
insertNote(note: Note): Observable<any>{
return this.httpClient.post(environment.apiUrl+"generalnotes/",note);


}



}
