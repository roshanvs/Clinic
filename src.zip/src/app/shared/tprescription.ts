export class Tprescription {

    testPrescriptionId: number;
        appointmentId: number;
        status: string;
}
