export class Appointment {



    appointmentId: number;
    patientId: number;
    doctorId: number;
    date: Date;
    status: string;
    tokken: number;
    receptionistId: number;
}
