export class User {

    
            userId: number;
            name: string;
            phone: string;
            address: string;
            roleId: number;
            email: string;
            dob: Date;
            password: string;
            isActive: string;
        }

