import { Mprescription } from './mprescription';

describe('Mprescription', () => {
  it('should create an instance', () => {
    expect(new Mprescription()).toBeTruthy();
  });
});
