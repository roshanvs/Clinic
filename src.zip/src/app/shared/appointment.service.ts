import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Appointment } from './appointment';

@Injectable({
  providedIn: 'root'
})
export class AppointmentService {
  appointments: Appointment[];
  appointmentIds: number[];

  constructor(private httpClient: HttpClient) { }
  getAppointmentsByDoctor(doctorId: number){
    this.httpClient.get(environment.apiUrl+"appointments/doctors/"
    +doctorId)
    .toPromise().then(
      response => this.appointments= response as Appointment[]
    );
  }

  getAppointmentIdsByPatient(patientId: number ,doctorId: number){
      this.httpClient.get(environment.apiUrl+"appointments/p/d/"+patientId+"&"+doctorId)
      .toPromise().then(
        response => this.appointmentIds =response as number[]
      );



  }

}
