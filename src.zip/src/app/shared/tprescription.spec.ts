import { Tprescription } from './tprescription';

describe('Tprescription', () => {
  it('should create an instance', () => {
    expect(new Tprescription()).toBeTruthy();
  });
});
