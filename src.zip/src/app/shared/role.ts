export class Role {
    roleId: number;
    roleName: string;
}
