import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Tprescription } from './tprescription';

@Injectable({
  providedIn: 'root'
})
export class TprescriptionService {
  tprescriptions : Tprescription[];
  constructor(private httpClient: HttpClient) { }
  getAllNotes(){
    return this.httpClient.get(environment.apiUrl+"testprescriptions").toPromise().then(
      response=> this.tprescriptions= response as Tprescription[]
    );



}}
