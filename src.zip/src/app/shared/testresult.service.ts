import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Testresult } from './testresult';

@Injectable({
  providedIn: 'root'
})
export class TestresultService {

  constructor(private htppClient: HttpClient) { }
  testresults: Testresult[];

  getAlltestResults(){
    this.htppClient.get(environment.apiUrl+"testresults").toPromise().then
    (response  => this.testresults= response as Testresult[]);

  }


}
