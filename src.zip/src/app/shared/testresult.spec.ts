import { Testresult } from './testresult';

describe('Testresult', () => {
  it('should create an instance', () => {
    expect(new Testresult()).toBeTruthy();
  });
});
