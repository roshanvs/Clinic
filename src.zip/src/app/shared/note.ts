export class Note {


    noteId: number;
    appointmentId: number;
    notes: string;
}
