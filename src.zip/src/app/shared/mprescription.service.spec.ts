import { TestBed } from '@angular/core/testing';

import { MprescriptionService } from './mprescription.service';

describe('MprescriptionService', () => {
  let service: MprescriptionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MprescriptionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
