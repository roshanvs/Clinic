export class Mprescription {
    medPrescriptionId: number;
        appointmentId: number;
        status: string;
}
