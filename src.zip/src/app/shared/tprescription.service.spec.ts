import { TestBed } from '@angular/core/testing';

import { TprescriptionService } from './tprescription.service';

describe('TprescriptionService', () => {
  let service: TprescriptionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TprescriptionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
