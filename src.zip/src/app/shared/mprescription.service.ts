import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Mprescription } from './mprescription';

@Injectable({
  providedIn: 'root'
})
export class MprescriptionService {
  mprescriptions: Mprescription[];

  constructor(private httpClient: HttpClient) { }
  getAllMPrescriptions(){
    return this.httpClient.get(environment.apiUrl+"medicalprescriptions").toPromise().then(
      response=> this.mprescriptions= response as Mprescription[]
    );

  }
}
