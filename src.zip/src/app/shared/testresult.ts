export class Testresult {

    resultId: number;
    labTechnicianId: number;
    testListId: number;
    testId: number;
    testValues: number;

}
