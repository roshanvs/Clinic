import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import {HttpClient} from '@angular/common/http'
import { User } from './user';
import {environment} from 'src/environments/environment'
import { Doctor } from 'src/app/shared/doctor'

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private httpClient: HttpClient,
              private router: Router) { }

              //verify login
              public loginVerify(user: User){
                console.log(user.email);
                console.log(user.password);

                return this.httpClient.get<User>(environment.apiUrl
                  +"users/emailpassword/"+user.email+"&"+user.password);


              }
              public getDoctorId(id: number){
                return this.httpClient.get<Doctor>(environment.apiUrl+"appointments/doctors/"+id);
              }

}
