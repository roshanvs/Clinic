import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { User } from 'src/app/shared/user'
import { AuthService } from 'src/app/shared/auth.service'
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  //declare variable for submit
isSubmitted: boolean=false;
  //declare variable for error
error: any='';

loginUser: User;
email: string="";
doctorId: number=0;


  constructor(private formBuilder: FormBuilder,
              private  authService: AuthService,
              private router: Router) { }


              ngOnInit(): void {
                //creative reactive form
                //userName password
                this.loginForm=this.formBuilder.group(
                  {
                    email: ['',[Validators.required]],
                    password: ['',[Validators.required]]
                  }
            );
            }
            get formControls(){
              return this.loginForm.controls;
            }
            
            //Login Verify Method
            loginCredentials(){
              this.isSubmitted = true;
              //form is valid
            
            if(this.loginForm.valid){
              //calling method from webservice
              this.authService.loginVerify(this.loginForm.value)
              .subscribe(
                data=>{
                  //success
                  console.log(data);
                  this.email=data.email;
                  localStorage.setItem('email',data.email);
                  sessionStorage.setItem('email',data.email);
                  localStorage.setItem('ACCESS_ROLE',data.roleId.toString());
                  //Form-level role based authentication
                  //Checking rolebased authorization
                  if(data.roleId===1){
                    
                    this.authService.getDoctorId(data.userId)
                    .subscribe(
                      docData=>{
                        console.log(docData);
                        localStorage.setItem('doctorId',docData.doctorId.toString());
                        

                    });
                    this.router.navigateByUrl('/home')
                   } else{
                    this.router.navigateByUrl('/login')
                  }
            
                },
                error=>{
                  console.log(error);
                  this.error="Invalid Username or password"
                }
              );
            }
            //form is invalid
            
            }
            }
            
