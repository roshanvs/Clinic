import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mprescriptions',
  templateUrl: './mprescriptions.component.html',
  styleUrls: ['./mprescriptions.component.scss']
})
export class MprescriptionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
