import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {MprescriptionService} from 'src/app/shared/mprescription.service'

@Component({
  selector: 'app-mprescription-list',
  templateUrl: './mprescription-list.component.html',
  styleUrls: ['./mprescription-list.component.scss']
})
export class MprescriptionListComponent implements OnInit {

  constructor(public mprescriptionService: MprescriptionService,
              private router: Router) { }

  ngOnInit(): void {

    this.mprescriptionService.getAllMPrescriptions();
  }
  btnMenu= function () {
    this.router.navigateByUrl('/menu');
};


}
