import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MprescriptionListComponent } from './mprescription-list.component';

describe('MprescriptionListComponent', () => {
  let component: MprescriptionListComponent;
  let fixture: ComponentFixture<MprescriptionListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MprescriptionListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MprescriptionListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
