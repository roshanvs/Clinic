import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MprescriptionsComponent } from './mprescriptions.component';

describe('MprescriptionsComponent', () => {
  let component: MprescriptionsComponent;
  let fixture: ComponentFixture<MprescriptionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MprescriptionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MprescriptionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
