import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mprescription',
  templateUrl: './mprescription.component.html',
  styleUrls: ['./mprescription.component.scss']
})
export class MprescriptionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
